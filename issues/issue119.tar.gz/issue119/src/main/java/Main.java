import org.aeonbits.owner.ConfigFactory;

public class Main {

    public static void main(String[] args) {
        Config config = ConfigFactory.create(Config.class);
        System.out.println("---> env: " + config.env());
        System.out.println("---> host: " + config.host());
        System.out.println("---> port: " + config.port());
    }
}
