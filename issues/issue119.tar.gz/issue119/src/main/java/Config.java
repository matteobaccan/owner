public interface Config extends org.aeonbits.owner.Config{
    @DefaultValue("qa") String env();
    @Key("${env}.server.host") String host();
    @Key("${env}.server.port") int port();
}
