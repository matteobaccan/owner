import org.aeonbits.owner.ConfigFactory;
import org.junit.Test;

import static org.aeonbits.owner.util.Collections.map;
import static org.junit.Assert.assertEquals;

public class ConfigTest {


    @Test
    public void testDefault() {
        Config config = ConfigFactory.create(Config.class);
        assertEquals("default", config.env());
        assertEquals("http://example.com", config.host());
        assertEquals(80, config.port());
    }

    @Test
    public void testQA1() {
        Config config = ConfigFactory.create(Config.class, map("env", "qa1"));
        assertEquals("qa1", config.env());
        assertEquals("http://example1.com", config.host());
        assertEquals(80, config.port());
    }

    @Test
    public void testQA2() {
        Config config = ConfigFactory.create(Config.class, map("env", "qa2"));
        assertEquals("qa2", config.env());
        assertEquals("http://example2.com", config.host());
        assertEquals(80, config.port());
    }

    @Test
    public void testQA3() {
        Config config = ConfigFactory.create(Config.class, map("env", "qa3"));
        assertEquals("qa3", config.env());
        assertEquals("http://example3.com", config.host());
        assertEquals(80, config.port());
    }

}
