public interface Config extends org.aeonbits.owner.Config{
    @DefaultValue("default")
    String env();

    @DefaultValue("${server.host}")
    @Key("${env}.server.host")
    String host();

    @DefaultValue("${server.port}")
    @Key("${env}.server.port")
    int port();
}
