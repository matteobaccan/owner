public interface Config extends org.aeonbits.owner.Config{
    @DefaultValue("default") String env();
    @Key("${env}.server.host") String host();
    @Key("${env}.server.port") int port();
}
