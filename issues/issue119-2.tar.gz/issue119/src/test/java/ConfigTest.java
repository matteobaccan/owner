import org.aeonbits.owner.ConfigFactory;
import org.junit.Test;

import static org.aeonbits.owner.util.Collections.map;
import static org.junit.Assert.assertEquals;

public class ConfigTest {

    @Test
    public void testDefault() {
        Config config = ConfigFactory.create(Config.class);
        assertEquals("default", config.env());
        assertEquals("http://default.com", config.host());
        assertEquals(80, config.port());
    }

    @Test
    public void testQA() {
        Config config = ConfigFactory.create(Config.class, map("env", "qa"));
        assertEquals("qa", config.env());
        assertEquals("http://example.com", config.host());
        assertEquals(80, config.port());
    }

}
